/**
 * Home Page — "Segredo Oculto Revelado"
 * Design: Premium Dark, fonte Apple system
 * Fundo futurista InfoPay
 */
import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Lock, ArrowRight } from "lucide-react";

const HERO_BG = "https://private-us-east-1.manuscdn.com/sessionFile/k0uItJusoJdSpuF9WHq4xB/sandbox/qYSjRZafOGW0vkX2EYcqm1-img-1_1771539619000_na1fn_aW5mb3BheS1mdXR1cmlzdGljLWJn.jpg?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvazB1SXRKdXNvSmRTcHVGOVdIcTR4Qi9zYW5kYm94L3FZU2pSWmFmT0dXMHZrWDJFWWNxbTEtaW1nLTFfMTc3MTUzOTYxOTAwMF9uYTFmbl9hVzVtYjNCaGVTMW1kWFIxY21semRHbGpMV0puLmpwZz94LW9zcy1wcm9jZXNzPWltYWdlL3Jlc2l6ZSx3XzE5MjAsaF8xOTIwL2Zvcm1hdCx3ZWJwL3F1YWxpdHkscV84MCIsIkNvbmRpdGlvbiI6eyJEYXRlTGVzc1RoYW4iOnsiQVdTOkVwb2NoVGltZSI6MTc5ODc2MTYwMH19fV19&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=bs8G~7IeejT3IFBqErEfVZjb6Qe1w226-yZOP2CpXdH17AigK1ptZYGq~sT7mKZxLF8QjTLRnpAWFQh26SHeXR6WRHPo1sLNO1euV9bD5F2WWLWys2aG68HJjbqxI6aFQJZq5Woh1b~3pE5fyLdIYAjoQI25DDT0i0Obwt~ckvS3H-j9xZYbsEjtVPMu2j-FLic2Cjj-0nkRP4CqLe5ByUzzkGmJd8ZV9GrjO3KUXt2gbVa4mfpu5wHdoDoiDWWPsbguWgBCiHHITooyQCxicgRiJqlIrneAdfcXL-1deNZ7SQ3hqKKiPylpyow0f6Y1v5IXkss8iec7BRXEtzN0BA__";

const LOGO_URL = "https://files.manuscdn.com/user_upload_by_module/session_file/310519663369261862/mEShBejFcKaDIKTf.png";

export default function Home() {
  const [, setLocation] = useLocation();
  const [loaded, setLoaded] = useState(false);
  const [lockOpen, setLockOpen] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setLoaded(true), 100);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (loaded) {
      const timer = setTimeout(() => setLockOpen(true), 800);
      return () => clearTimeout(timer);
    }
  }, [loaded]);

  const handleEnter = () => {
    setLocation("/landing");
  };

  return (
    <div className="relative min-h-screen overflow-hidden">
      {/* Background image */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${HERO_BG})` }}
      />
      <div className="absolute inset-0 bg-[#0a1628]/50" />

      {/* Main content */}
      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-4">
        {/* Logo */}
        <div
          className={`mb-10 transition-all duration-1000 ease-out ${
            loaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"
          }`}
        >
          <img
            src={LOGO_URL}
            alt="InfoPay"
            className="h-14 sm:h-18 md:h-20 w-auto drop-shadow-[0_0_30px_rgba(16,185,129,0.3)]"
          />
        </div>

        {/* Lock icon */}
        <div
          className={`mb-8 transition-all duration-700 ease-out ${
            loaded ? "opacity-100 scale-100" : "opacity-0 scale-75"
          }`}
          style={{ transitionDelay: "300ms" }}
        >
          <div className={`relative p-5 rounded-full border-2 transition-all duration-700 ${
            lockOpen
              ? "border-emerald-400/60 bg-emerald-500/10 shadow-[0_0_40px_rgba(16,185,129,0.25)]"
              : "border-white/20 bg-white/5"
          }`}>
            <Lock
              className={`w-8 h-8 sm:w-10 sm:h-10 transition-all duration-700 ${
                lockOpen ? "text-emerald-400" : "text-white/60"
              }`}
            />
            {lockOpen && (
              <div className="absolute inset-0 rounded-full animate-ping bg-emerald-400/10" />
            )}
          </div>
        </div>

        {/* Title */}
        <h1
          className={`text-center transition-all duration-1000 ease-out ${
            loaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
          style={{ transitionDelay: "500ms" }}
        >
          <span className="block text-lg sm:text-xl md:text-2xl font-medium tracking-[0.3em] uppercase text-emerald-400/80 mb-3">
            
          </span>
          <span className="block text-4xl sm:text-5xl md:text-7xl lg:text-8xl font-bold text-white leading-[0.95] tracking-tight">
            O Segredo
          </span>
          <span className="block text-4xl sm:text-5xl md:text-7xl lg:text-8xl font-bold leading-[0.95] tracking-tight mt-1">
            <span className="text-white">Oculto </span>
            <span className="bg-gradient-to-r from-emerald-400 via-emerald-300 to-teal-400 bg-clip-text text-transparent">
              Revelado
            </span>
          </span>
        </h1>

        {/* Subtitle */}
        <p
          className={`mt-6 sm:mt-8 text-center text-sm sm:text-base md:text-lg text-white/50 font-light max-w-md tracking-wide transition-all duration-1000 ease-out ${
            loaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"
          }`}
          style={{ transitionDelay: "700ms" }}
        >
          Descubra agora o segredo que está por trás desse sistema automatizado.
        </p>

        {/* Decorative line */}
        <div
          className={`mt-6 sm:mt-8 w-20 h-px bg-gradient-to-r from-transparent via-emerald-400/50 to-transparent transition-all duration-1000 ${
            loaded ? "opacity-100 scale-x-100" : "opacity-0 scale-x-0"
          }`}
          style={{ transitionDelay: "900ms" }}
        />

        {/* CTA Button */}
        <div
          className={`mt-8 sm:mt-10 transition-all duration-1000 ease-out ${
            loaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"
          }`}
          style={{ transitionDelay: "1100ms" }}
        >
          <button
            onClick={handleEnter}
            className="group relative px-10 sm:px-14 py-4 sm:py-5 bg-gradient-to-r from-emerald-600 to-emerald-500 text-white font-semibold text-base sm:text-lg tracking-wide rounded-lg overflow-hidden transition-all duration-300 hover:shadow-[0_0_40px_rgba(16,185,129,0.4)] animate-pulse-glow"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent animate-shimmer" />
            <span className="relative flex items-center gap-3">
              Entrar
              <ArrowRight className="w-5 h-5 transition-transform duration-300 group-hover:translate-x-1" />
            </span>
          </button>
        </div>

        {/* Bottom badge */}
        <div
          className={`mt-12 sm:mt-16 flex items-center gap-2 text-xs text-white/30 tracking-wider uppercase transition-all duration-1000 ${
            loaded ? "opacity-100" : "opacity-0"
          }`}
          style={{ transitionDelay: "1400ms" }}
        >
          <div className="w-1.5 h-1.5 rounded-full bg-emerald-400/50" />
          <span>Acesso Exclusivo</span>
          <div className="w-1.5 h-1.5 rounded-full bg-emerald-400/50" />
        </div>
      </div>
    </div>
  );
}
