/**
 * Landing Page — VSL + Botão Comunidade
 * Design: Fundo futurista InfoPay, fonte Apple system
 * - Logo no cabeçalho (sem botão voltar)
 * - Efeito atrativo para clicar na VSL
 * - Botão comunidade aparece nos últimos 10s do vídeo, com efeito bounce
 */
import { useEffect, useState, useRef, useCallback } from "react";
import { Users, Play } from "lucide-react";

const FUTURISTIC_BG = "https://private-us-east-1.manuscdn.com/sessionFile/k0uItJusoJdSpuF9WHq4xB/sandbox/qYSjRZafOGW0vkX2EYcqm1-img-1_1771539619000_na1fn_aW5mb3BheS1mdXR1cmlzdGljLWJn.jpg?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvazB1SXRKdXNvSmRTcHVGOVdIcTR4Qi9zYW5kYm94L3FZU2pSWmFmT0dXMHZrWDJFWWNxbTEtaW1nLTFfMTc3MTUzOTYxOTAwMF9uYTFmbl9hVzVtYjNCaGVTMW1kWFIxY21semRHbGpMV0puLmpwZz94LW9zcy1wcm9jZXNzPWltYWdlL3Jlc2l6ZSx3XzE5MjAsaF8xOTIwL2Zvcm1hdCx3ZWJwL3F1YWxpdHkscV84MCIsIkNvbmRpdGlvbiI6eyJEYXRlTGVzc1RoYW4iOnsiQVdTOkVwb2NoVGltZSI6MTc5ODc2MTYwMH19fV19&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=bs8G~7IeejT3IFBqErEfVZjb6Qe1w226-yZOP2CpXdH17AigK1ptZYGq~sT7mKZxLF8QjTLRnpAWFQh26SHeXR6WRHPo1sLNO1euV9bD5F2WWLWys2aG68HJjbqxI6aFQJZq5Woh1b~3pE5fyLdIYAjoQI25DDT0i0Obwt~ckvS3H-j9xZYbsEjtVPMu2j-FLic2Cjj-0nkRP4CqLe5ByUzzkGmJd8ZV9GrjO3KUXt2gbVa4mfpu5wHdoDoiDWWPsbguWgBCiHHITooyQCxicgRiJqlIrneAdfcXL-1deNZ7SQ3hqKKiPylpyow0f6Y1v5IXkss8iec7BRXEtzN0BA__";

const LOGO_URL = "https://files.manuscdn.com/user_upload_by_module/session_file/310519663369261862/mEShBejFcKaDIKTf.png";

const COMMUNITY_URL = "https://linklist.bio/ULTRASECRETO";

// YouTube video ID
const VIDEO_ID = "EFFFNSxDYnE";

export default function Landing() {
  const [loaded, setLoaded] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [showButton, setShowButton] = useState(false);
  const playerRef = useRef<any>(null);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const timer = setTimeout(() => setLoaded(true), 100);
    return () => clearTimeout(timer);
  }, []);

  // Load YouTube IFrame API
  useEffect(() => {
    if ((window as any).YT && (window as any).YT.Player) return;
    const tag = document.createElement("script");
    tag.src = "https://www.youtube.com/iframe_api";
    document.head.appendChild(tag);
  }, []);

  const startTracking = useCallback(() => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    intervalRef.current = setInterval(() => {
      const player = playerRef.current;
      if (!player || typeof player.getDuration !== "function") return;
      const duration = player.getDuration();
      const currentTime = player.getCurrentTime();
      if (duration > 0 && currentTime > 0) {
        const timeLeft = duration - currentTime;
        if (timeLeft <= 10) {
          setShowButton(true);
          if (intervalRef.current) clearInterval(intervalRef.current);
        }
      }
    }, 1000);
  }, []);

  const handlePlay = useCallback(() => {
    setIsPlaying(true);
    // Wait for iframe to render, then init YT player
    setTimeout(() => {
      const onYTReady = () => {
        playerRef.current = new (window as any).YT.Player("yt-player", {
          events: {
            onStateChange: (event: any) => {
              // 1 = playing
              if (event.data === 1) {
                startTracking();
              }
            },
          },
        });
      };
      if ((window as any).YT && (window as any).YT.Player) {
        onYTReady();
      } else {
        (window as any).onYouTubeIframeAPIReady = onYTReady;
      }
    }, 500);
  }, [startTracking]);

  useEffect(() => {
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, []);

  return (
    <div className="relative min-h-screen overflow-hidden">
      {/* Fundo futurista InfoPay */}
      <div
        className="fixed inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${FUTURISTIC_BG})` }}
      />
      <div className="fixed inset-0 bg-[#0a1628]/40" />

      {/* Main content — VSL + Botão */}
      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-4 py-12">
        {/* Logo */}
        <img
          src={LOGO_URL}
          alt="InfoPay"
          className={`h-14 sm:h-18 md:h-22 w-auto mb-8 sm:mb-10 transition-all duration-1000 ease-out ${
            loaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"
          }`}
        />

        {/* Título acima da VSL */}
        <h1
          className={`text-center mb-8 sm:mb-10 transition-all duration-1000 ease-out ${
            loaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
          style={{ transitionDelay: "100ms" }}
        >
          <span className="block text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight tracking-tight">
            <span className="bg-gradient-to-r from-emerald-400 via-emerald-300 to-teal-400 bg-clip-text text-transparent">REVELADO:</span>{" "}
            UM NOVO MODELO DE NEGÓCIO DIGITAL 100% AUTOMATIZADO.
          </span>
        </h1>

        {/* VSL Video Player */}
        <div
          ref={containerRef}
          className={`w-full max-w-3xl transition-all duration-1000 ease-out ${
            loaded ? "opacity-100 translate-y-0 scale-100" : "opacity-0 translate-y-8 scale-95"
          }`}
          style={{ transitionDelay: "200ms" }}
        >
          <div className={`relative rounded-2xl overflow-hidden border shadow-[0_0_80px_rgba(16,185,129,0.12),0_20px_60px_rgba(0,0,0,0.5)] bg-black/50 backdrop-blur-sm ${
            !isPlaying ? "border-emerald-400/30 animate-glow-ring" : "border-white/10"
          }`}>
            {/* Aspect ratio 16:9 */}
            <div className="relative w-full" style={{ paddingBottom: "56.25%" }}>
              {!isPlaying ? (
                /* Thumbnail com efeito atrativo para clicar */
                <div className="absolute inset-0 flex items-center justify-center bg-[#0a1628] cursor-pointer group" onClick={handlePlay}>
                  {/* Thumbnail do YouTube */}
                  <img
                    src={`https://img.youtube.com/vi/${VIDEO_ID}/maxresdefault.jpg`}
                    alt="Assistir vídeo"
                    className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:opacity-80 transition-opacity duration-500"
                  />
                  {/* Overlay escuro */}
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0a1628] via-[#0a1628]/40 to-[#0a1628]/60" />

                  {/* Botão play com efeito pulsante */}
                  <div className="relative z-10 flex flex-col items-center gap-4">
                    <div className="animate-click-me">
                      <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-full bg-emerald-500/20 backdrop-blur-sm border-2 border-emerald-400/50 flex items-center justify-center transition-all duration-300 group-hover:bg-emerald-500/30 group-hover:border-emerald-400/70 group-hover:scale-110">
                        <Play className="w-8 h-8 sm:w-10 sm:h-10 text-emerald-400 ml-1" fill="currentColor" />
                      </div>
                    </div>
                    <span className="text-white/80 text-sm sm:text-base font-medium tracking-wide animate-pulse">
                      Clique para assistir
                    </span>
                  </div>

                  {/* Setas animadas apontando para o play */}
                  <div className="absolute top-1/2 left-4 sm:left-8 -translate-y-1/2 text-emerald-400/40 animate-pulse text-2xl sm:text-3xl">
                    ▶
                  </div>
                  <div className="absolute top-1/2 right-4 sm:right-8 -translate-y-1/2 text-emerald-400/40 animate-pulse text-2xl sm:text-3xl" style={{ animationDelay: "0.5s" }}>
                    ◀
                  </div>
                </div>
              ) : (
                /* YouTube iframe com API habilitada */
                <iframe
                  id="yt-player"
                  className="absolute inset-0 w-full h-full"
                  src={`https://www.youtube.com/embed/${VIDEO_ID}?rel=0&modestbranding=1&autoplay=1&enablejsapi=1&origin=${window.location.origin}`}
                  title="VSL"
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                  allowFullScreen
                />
              )}
            </div>
          </div>
        </div>

        {/* CTA — Entrar na Comunidade (aparece nos últimos 10s do vídeo) */}
        <div
          className={`mt-10 sm:mt-12 transition-all duration-700 ease-out ${
            showButton
              ? "opacity-100 translate-y-0 scale-100"
              : "opacity-0 translate-y-8 scale-90 pointer-events-none"
          }`}
        >
          <a
            href={COMMUNITY_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="group relative inline-flex items-center gap-3 px-10 sm:px-14 py-4 sm:py-5 bg-gradient-to-r from-emerald-600 to-emerald-500 text-white font-semibold text-base sm:text-lg tracking-wide rounded-lg overflow-hidden transition-all duration-300 hover:shadow-[0_0_40px_rgba(16,185,129,0.4)] animate-bounce-attention"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent animate-shimmer" />
            <Users className="relative w-5 h-5" />
            <span className="relative">Entrar na Comunidade</span>
          </a>
        </div>
      </div>
    </div>
  );
}
