# Ideias de Design — Segredo Oculto Revelado

## Contexto
Site com duas vistas: página inicial (splash/portal) com o nome "Segredo Oculto Revelado" e botão para entrar; e uma landing page com VSL (Video Sales Letter) e botão para entrar na comunidade. Marca associada: InfoPay. Cores da marca: azul escuro, verde, ciano.

---

<response>
## Ideia 1 — "Noir Digital" (Estética Cyberpunk Minimalista)
<probability>0.07</probability>

**Design Movement:** Cyberpunk minimalista com influências de UI de ficção científica.

**Core Principles:**
1. Contraste extremo entre fundo escuro e acentos neon
2. Tipografia monoespaçada para títulos, criando sensação de "código secreto"
3. Espaço negativo generoso para criar tensão visual
4. Elementos geométricos angulares e linhas de grid subtis

**Color Philosophy:** Fundo quase preto (#0a0e17) com acentos em verde neon (#00ff88) e ciano (#00d4ff) — evoca a ideia de "segredo revelado" como se fosse um terminal hacker. O verde neon conecta com o verde da marca InfoPay.

**Layout Paradigm:** Layout vertical full-screen com scroll snap. Página inicial ocupa 100vh com o título centralizado e animação de "revelação". Landing page usa layout assimétrico com vídeo à esquerda e CTA à direita em desktop.

**Signature Elements:**
1. Efeito de "glitch" sutil no título principal
2. Linhas de scanning horizontais semi-transparentes no fundo
3. Bordas com gradiente neon nos cards e botões

**Interaction Philosophy:** Hover effects com glow neon, transições rápidas e precisas, cursor personalizado.

**Animation:** Texto do título aparece letra a letra como se estivesse a ser digitado. Botões pulsam com glow. Transição entre páginas com efeito de "static/noise".

**Typography System:** Títulos em JetBrains Mono (bold), corpo em Space Grotesk (regular/medium). Hierarquia clara com tamanhos contrastantes.
</response>

---

<response>
## Ideia 2 — "Vault Reveal" (Estética Premium/Luxury Dark)
<probability>0.08</probability>

**Design Movement:** Dark luxury com influências de branding financeiro premium e estética de cofre/vault.

**Core Principles:**
1. Elegância através de restrição — poucos elementos, muito impacto
2. Profundidade através de camadas sutis de sombra e blur
3. Movimento controlado que transmite confiança e exclusividade
4. Hierarquia tipográfica forte com serif display

**Color Philosophy:** Azul profundo (#0b1628) como base, com gradientes que vão do azul escuro ao verde esmeralda (#10b981), refletindo a paleta InfoPay. Dourado sutil (#c9a84c) como acento terciário para transmitir valor e exclusividade. O conceito de "segredo" é reforçado pela escuridão, e o "revelado" pelos acentos luminosos.

**Layout Paradigm:** Página inicial com layout centrado dramático — logo grande, título em serif elegante, e um único botão CTA. Landing page com layout em "Z-pattern": vídeo hero no topo, benefícios em grid assimétrico, CTA final. Uso de max-width estreito (800px) para criar foco.

**Signature Elements:**
1. Efeito de "porta de cofre a abrir" na transição da splash para a landing
2. Gradiente radial sutil que segue o cursor do rato
3. Ícone de cadeado que se transforma em cadeado aberto

**Interaction Philosophy:** Movimentos suaves e lentos que transmitem peso e importância. Hover com scale sutil e mudança de opacidade. Nada brusco.

**Animation:** Fade-in elegante com slight upward motion. Logo aparece com scale de 0.95 para 1. Botão CTA com pulse suave e contínuo. Vídeo player com border glow.

**Typography System:** Títulos em Playfair Display (bold) para elegância, corpo em DM Sans (regular/medium) para legibilidade moderna. Contraste entre serif e sans-serif cria sofisticação.
</response>

---

<response>
## Ideia 3 — "Signal Burst" (Estética Bold/Impactful Marketing)
<probability>0.06</probability>

**Design Movement:** Marketing de alta conversão com estética bold e direta, influenciada por design de lançamentos digitais brasileiros.

**Core Principles:**
1. Impacto visual imediato — o utilizador sabe exatamente o que fazer em 2 segundos
2. Cores vibrantes e contrastantes que captam atenção
3. Urgência visual sem ser agressivo
4. Prova social e autoridade visual

**Color Philosophy:** Fundo escuro azulado (#0f172a) com gradientes vibrantes de azul (#2563eb) para verde (#22c55e), espelhando diretamente a identidade InfoPay. Branco puro para texto principal. Amarelo (#fbbf24) como cor de urgência/destaque pontual.

**Layout Paradigm:** Página inicial full-screen com stack vertical: logo no topo, título grande e impactante no centro, subtítulo persuasivo, e botão CTA oversized. Landing page com layout de "funil": hero com vídeo centrado, seção de benefícios com ícones, e CTA sticky no fundo mobile.

**Signature Elements:**
1. Gradiente animado no fundo que pulsa lentamente entre azul e verde
2. Badge de "EXCLUSIVO" ou "ACESSO LIMITADO" com animação de brilho
3. Seta animada apontando para o CTA

**Interaction Philosophy:** CTAs grandes e impossíveis de ignorar. Feedback tátil nos botões (scale + shadow). Scroll suave com seções que entram com fade.

**Animation:** Background gradient que se move lentamente. Título com fade-in + slide-up. Botão com shimmer effect contínuo. Contador ou badge com pulse.

**Typography System:** Títulos em Sora (extra-bold) para impacto máximo, corpo em Inter (regular/medium). Tamanhos grandes para títulos (clamp responsivo), espaçamento apertado em títulos para densidade.
</response>

---

## Decisão
**Escolha: Ideia 2 — "Vault Reveal" (Estética Premium/Luxury Dark)**

Esta abordagem é a mais adequada porque:
- O conceito de "segredo oculto revelado" alinha-se perfeitamente com a metáfora do cofre
- A estética premium transmite confiança e valor, essencial para um produto digital
- As cores da marca InfoPay (azul escuro + verde) integram-se naturalmente na paleta luxury dark
- A tipografia serif + sans-serif cria distinção visual sem cair nos padrões genéricos
